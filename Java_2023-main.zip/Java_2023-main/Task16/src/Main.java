public class Main {
    public static void main(String[] args) {
        var exp = new Exception2();
        exp.exceptionDemo();
    }
}