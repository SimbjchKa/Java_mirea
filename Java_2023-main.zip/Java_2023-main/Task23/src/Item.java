public interface Item {
    String getName();
    int getCost();
    String getDescription();
}