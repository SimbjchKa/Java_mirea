package practice_24;

public class IllegalTableNumber extends IllegalArgumentException {
    public IllegalTableNumber(String message) {
        super(message);
    }
}
