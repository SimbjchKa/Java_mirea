import java.lang.*;
public class TestBook {
    public static  void main(String[] args){
        Book d1 = new Book(" Lorem", 555);
        Book d2 = new Book(" Lorem2", 452);
        System.out.print(d1);
        System.out.print(d2);

    }
}
