import java.lang.*;
public class TestBall {
    public static  void main(String[] args){
        Ball d1 = new Ball(" red", 5.5);
        Ball d2 = new Ball(" green", 3.2);
        System.out.print(d1);
        System.out.print(d2);
    }
}
