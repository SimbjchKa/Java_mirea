public class EmployeeView {
    public void printEmployeeDetails(String name, double salary) {
        System.out.println("Employee: ");
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
    }
}