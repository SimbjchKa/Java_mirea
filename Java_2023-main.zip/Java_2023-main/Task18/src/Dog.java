public class Dog extends Animal{
}
