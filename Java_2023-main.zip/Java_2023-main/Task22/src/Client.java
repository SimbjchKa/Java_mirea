class Client {
    void Sit(IChair chair) {
        chair.sit();
    }
}