public interface IChair {
    void sit();
}
