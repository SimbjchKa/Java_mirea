public interface IComplexAbstractFactory {
    public void CreateComplex();
    public void CreateComplex(int real, int image);
}
