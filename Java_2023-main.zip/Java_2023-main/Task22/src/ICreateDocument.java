public interface ICreateDocument {
    IDocument createNew();
    IDocument createOpen();
}