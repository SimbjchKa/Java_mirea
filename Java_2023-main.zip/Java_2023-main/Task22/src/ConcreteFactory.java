public class ConcreteFactory implements IComplexAbstractFactory {
    @Override
    public void CreateComplex() {

    }

    @Override
    public void CreateComplex(int real, int image) {

    }
}
