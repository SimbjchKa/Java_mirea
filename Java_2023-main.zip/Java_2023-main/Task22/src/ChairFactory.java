abstract class ChairFactory {
    abstract IChair createChair();
}