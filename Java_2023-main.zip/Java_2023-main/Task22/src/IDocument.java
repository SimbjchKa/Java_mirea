public interface IDocument {
    void open();
    void save();
}
