class MagicChair implements IChair {
    @Override
    public void sit() {
        System.out.println("Сидим на магическом стуле");
    }
}