class VictorianChair implements IChair {
    @Override
    public void sit() {
        System.out.println("Сидим на викторианском стуле");
    }
}
