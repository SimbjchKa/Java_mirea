class MultifunctionalChair implements IChair {
    @Override
    public void sit() {
        System.out.println("Сидим на многофункциональном стуле");
    }
}