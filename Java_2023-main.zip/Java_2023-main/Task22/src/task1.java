public class task1 {
}
